package com.zohight.voice;

/**
 * เสียงพูดใต้น้ำ (แบบคนจมน้ำ): อู้ ตัดเสียงแหลม + สั่นพริ้วเหมือนฟองอากาศ + โทนเสียงแกว่งเล็กน้อย
 * ใช้กับเสียงของคนที่กำลังพูดอยู่ใต้น้ำ (เรียกก่อนส่งขึ้นเซิร์ฟเวอร์)
 */
public final class DrownFx {
    private static final int RATE = 16000;
    private final float[] buf = new float[256];
    private int wp = 0;
    private double lp1 = 0, lp2 = 0, t = 0;

    public void process(short[] x, int n) {
        double a = 1.0 - Math.exp(-2.0 * Math.PI * 900.0 / RATE);
        for (int i = 0; i < n; i++) {
            double s = x[i] / 32768.0;
            lp1 += a * (s - lp1);
            lp2 += a * (lp1 - lp2);
            buf[wp] = (float) lp2;
            // โทนแกว่ง (vibrato) ด้วยดีเลย์ที่เปลี่ยนตามเวลา
            double d = 14.0 + 9.0 * Math.sin(2.0 * Math.PI * 4.6 * t) + 4.0 * Math.sin(2.0 * Math.PI * 8.3 * t);
            double pos = wp - d;
            int i0 = (int) Math.floor(pos);
            double fr = pos - i0;
            double y = buf[i0 & 255] + (buf[(i0 + 1) & 255] - buf[i0 & 255]) * fr;
            // ฟองอากาศ: ระดับเสียงสั่นขึ้นลง
            double am = 0.62 + 0.38 * Math.sin(2.0 * Math.PI * 7.3 * t) * Math.sin(2.0 * Math.PI * 2.9 * t + 1.0);
            y *= am * 1.9;
            if (y > 0.95) y = 0.95;
            if (y < -0.95) y = -0.95;
            x[i] = (short) Math.round(y < 0 ? y * 32768 : y * 32767);
            wp = (wp + 1) & 255;
            t += 1.0 / RATE;
        }
    }
}
