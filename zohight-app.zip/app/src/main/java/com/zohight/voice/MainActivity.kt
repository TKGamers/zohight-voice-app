package com.zohight.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var pendingStart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Core.ns = Prefs.ns(this)
        Core.echo = Prefs.echo(this)
        window.statusBarColor = Color.parseColor("#06100d")
        window.navigationBarColor = Color.parseColor("#06100d")
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#06100d"))
        setContentView(web)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(this), "ZV")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        Core.listener = { pushState() }
        pushState()
    }

    override fun onPause() {
        Core.listener = null
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // กดย้อนกลับ = พับแอปไว้เบื้องหลัง (ไมค์ยังทำงานต่อ)
        moveTaskToBack(true)
    }

    fun pushState() {
        val js = "window.onNative && window.onNative(" + Core.json(this) + ")"
        web.post { web.evaluateJavascript(js, null) }
    }

    /** ขอสิทธิ์ไมค์/แจ้งเตือน แล้วเริ่มเซอร์วิส */
    fun startVoice() {
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) {
            pendingStart = true
            requestPermissions(need.toTypedArray(), 11)
            return
        }
        doStart()
    }

    private fun doStart() {
        val i = Intent(this, VoiceService::class.java)
        i.action = VoiceService.ACTION_START
        startForegroundService(i)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                if (pendingStart) doStart()
            } else {
                Core.error = "ต้องอนุญาตการใช้ไมค์ก่อน ไปที่ ตั้งค่า > แอป > ZoHight Voice > สิทธิ์"
                pushState()
            }
            pendingStart = false
        }
    }
}

/** สะพานให้หน้าเว็บ (index.html) สั่งงานฝั่งแอป */
class Bridge(private val act: MainActivity) {

    @JavascriptInterface
    fun getState(): String = Core.json(act)

    @JavascriptInterface
    fun link(code: String) {
        Thread {
            try {
                val digits = code.filter { ch -> ch.isDigit() }
                val u = URL(Prefs.server(act).trimEnd('/') + "/api/link")
                val c = u.openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 70000
                c.readTimeout = 70000
                c.setRequestProperty("content-type", "application/json")
                val body = JSONObject().put("code", digits).toString().toByteArray()
                c.outputStream.use { os -> os.write(body) }
                val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
                val txt = stream?.bufferedReader()?.use { r -> r.readText() } ?: "{}"
                val j = JSONObject(txt)
                if (j.optBoolean("ok")) {
                    Prefs.save(act, j.getString("token"), j.getString("name"))
                    Core.error = ""
                } else {
                    Core.error = j.optString("error", "เชื่อมไม่สำเร็จ")
                }
            } catch (e: Exception) {
                Core.error = "ติดต่อเซิร์ฟเวอร์ไม่ได้ ลองใหม่อีกครั้ง (เซิร์ฟเวอร์ฟรีอาจกำลังตื่น)"
            }
            act.pushState()
        }.start()
    }

    @JavascriptInterface
    fun start() {
        act.runOnUiThread { act.startVoice() }
    }

    @JavascriptInterface
    fun stop() {
        act.runOnUiThread {
            val i = Intent(act, VoiceService::class.java)
            i.action = VoiceService.ACTION_STOP
            act.startService(i)
        }
    }

    @JavascriptInterface
    fun setMic(on: Boolean) {
        val c = Core.client
        if (c != null) c.setMic(on) else Core.mic = on
        act.pushState()
    }

    @JavascriptInterface
    fun setDeaf(on: Boolean) {
        val c = Core.client
        if (c != null) c.setDeaf(on) else Core.deaf = on
        act.pushState()
    }

    @JavascriptInterface
    fun setRange(n: Int) {
        val c = Core.client
        if (c != null) c.setRange(n) else Core.range = n
        act.pushState()
    }

    @JavascriptInterface
    fun setNs(level: Int) {
        Core.ns = level
        Prefs.saveNs(act, level)
        act.pushState()
    }

    @JavascriptInterface
    fun setEcho(mode: String) {
        Core.echo = mode
        Prefs.saveEcho(act, mode)
        act.pushState()
    }

    @JavascriptInterface
    fun unlink() {
        stop()
        Prefs.clear(act)
        Core.resetRuntime()
        act.pushState()
    }

    @JavascriptInterface
    fun batterySettings() {
        act.runOnUiThread {
            try {
                act.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                Core.error = "เปิดหน้าตั้งค่าแบตเตอรี่ไม่ได้ ไปที่ ตั้งค่า > แอป > ZoHight Voice > แบตเตอรี่ > ไม่จำกัด"
                act.pushState()
            }
        }
    }
}
