package com.zohight.voice

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** สถานะกลางของแอป ใช้ร่วมกันระหว่างหน้าจอ (WebView) กับเซอร์วิสเบื้องหลัง */
object Core {
    @Volatile var client: VoiceClient? = null

    // ค่าที่หน้าจอใช้แสดงผล
    @Volatile var running = false
    @Volatile var conn = "idle"          // idle | connecting | connected | reconnecting
    @Volatile var online = false         // อยู่ในเกมหรือไม่
    @Volatile var mic = true
    @Volatile var deaf = false
    @Volatile var range = 15
    @Volatile var maxRange = 30         // เพดานระยะเสียง (แอดมินตั้งที่เซิร์ฟเวอร์ MAX_RANGE)
    @Volatile var ns = 1                // ตัดเสียงรบกวน 0=ปิด 1=กลาง 2=แรง
    @Volatile var echo = "auto"         // กันเสียงสะท้อน auto | on | off
    @Volatile var far = 0f              // ระดับเสียงที่กำลังเล่นออกลำโพง (ใช้กันเสียงสะท้อน)
    @Volatile var speaking = false
    @Volatile var level = 0f
    @Volatile var hear: List<Triple<String, Float, Boolean>> = emptyList()  // ชื่อ, ความดัง, ผ่านโทรศัพท์หรือไม่
    @Volatile var gain = 1f             // ความดังไมค์ของฉัน (0.25-4)
    @Volatile var agc = true            // ปรับความดังไมค์อัตโนมัติ
    @Volatile var listen = 1f           // ความดังเสียงคนอื่น (เฉพาะในแอปนี้)
    @Volatile var diagSent = 0          // แพ็กเก็ตเสียงที่ส่งออกต่อวินาที (ไว้ตรวจปัญหา)
    @Volatile var diagRecv = 0          // แพ็กเก็ตเสียงที่รับเข้าต่อวินาที
    @Volatile var diagMic = 0f          // ระดับไมค์ล่าสุด 0-1
    @Volatile var diagMode = "media"    // media | phone
    @Volatile var diagDuck = false      // กำลังใช้ระบบลดไมค์กันเสียงสะท้อนอยู่หรือไม่
    @Volatile var uw = false            // กำลังอยู่ใต้น้ำ (ใช้เสียงแบบคนจมน้ำ)
    @Volatile var callWith = ""         // คู่สายโทรศัพท์
    @Volatile var callSt = ""           // out | in | active | "" (ไม่มีสาย)
    @Volatile var error = ""

    // ตัวแจ้งเตือนเมื่อสถานะเปลี่ยน
    @Volatile var listener: (() -> Unit)? = null        // หน้าจอ
    @Volatile var onSettings: (() -> Unit)? = null      // อัปเดตแจ้งเตือน (ปุ่มไมค์/หู)
    @Volatile var stopService: (() -> Unit)? = null     // ให้เซอร์วิสปิดตัวเอง

    fun notifyChange() {
        listener?.invoke()
    }

    fun resetRuntime() {
        running = false
        conn = "idle"
        online = false
        speaking = false
        level = 0f
        hear = emptyList()
        far = 0f
        callWith = ""
        callSt = ""
    }

    fun json(c: Context): String {
        val o = JSONObject()
        o.put("native", true)
        o.put("linked", Prefs.token(c).isNotEmpty())
        o.put("name", Prefs.name(c))
        o.put("running", running)
        o.put("conn", conn)
        o.put("online", online)
        o.put("mic", mic)
        o.put("deaf", deaf)
        o.put("range", range)
        o.put("max", maxRange)
        o.put("ns", ns)
        o.put("echo", echo)
        o.put("gain", gain.toDouble())
        o.put("agc", agc)
        o.put("listen", listen.toDouble())
        o.put("diag", JSONObject().put("sent", diagSent).put("recv", diagRecv).put("mic", diagMic.toDouble()).put("mode", diagMode).put("duck", diagDuck))
        if (callSt.isNotEmpty()) {
            o.put("call", JSONObject().put("with", callWith).put("st", callSt))
        } else {
            o.put("call", JSONObject.NULL)
        }
        o.put("speaking", speaking)
        o.put("level", level.toDouble())
        val arr = JSONArray()
        for (p in hear) {
            arr.put(JSONObject().put("n", p.first).put("v", p.second.toDouble()).put("ph", p.third))
        }
        o.put("hear", arr)
        val e = error
        if (e.isNotEmpty()) {
            o.put("error", e)
            error = ""
        }
        return o.toString()
    }
}
