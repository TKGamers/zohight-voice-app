package com.zohight.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** เซอร์วิสเบื้องหลัง (Foreground Service ชนิดไมค์) ทำให้ไมค์ทำงานต่อได้แม้สลับไปเล่นเกมเต็มจอ */
class VoiceService : Service() {

    companion object {
        const val ACTION_START = "com.zohight.voice.START"
        const val ACTION_STOP = "com.zohight.voice.STOP"
        const val ACTION_MIC = "com.zohight.voice.MIC"
        const val ACTION_EAR = "com.zohight.voice.EAR"
        private const val CH = "zv_voice"
        private const val NID = 1
    }

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            shutdown()
        } else if (action == ACTION_MIC) {
            Core.client?.toggleMic()
            refresh()
        } else if (action == ACTION_EAR) {
            Core.client?.toggleDeaf()
            refresh()
        } else {
            begin()
        }
        return START_NOT_STICKY
    }

    private fun begin() {
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NID, n)
        }
        if (wake == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zv:voice")
            w.setReferenceCounted(false)
            wake = w
        }
        wake?.acquire(12 * 60 * 60 * 1000L)
        if (Core.client == null) Core.client = VoiceClient(applicationContext)
        Core.stopService = { shutdown() }
        Core.onSettings = { refresh() }
        Core.client?.start()
        refresh()
    }

    private fun shutdown() {
        Core.client?.stop()
        Core.stopService = null
        Core.onSettings = null
        try {
            wake?.release()
        } catch (_: Exception) {
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        Core.client?.stop()
        try {
            wake?.release()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, "ZoHight Voice", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun refresh() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NID, buildNotification())
    }

    private fun servicePi(action: String, code: Int): PendingIntent {
        val i = Intent(this, VoiceService::class.java)
        i.action = action
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val open = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val micOn = Core.mic && !Core.deaf
        val text = if (Core.deaf) "ปิดหูอยู่" else if (!Core.mic) "ปิดไมค์อยู่" else "ไมค์เปิดอยู่ คนใกล้ๆ ในเกมได้ยินคุณ"
        val icon = Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now)
        val b = Notification.Builder(this, CH)
        b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
        b.setContentTitle("ZoHight Voice")
        b.setContentText(text)
        b.setContentIntent(open)
        b.setOngoing(true)
        b.addAction(Notification.Action.Builder(icon, if (micOn) "ปิดไมค์" else "เปิดไมค์", servicePi(ACTION_MIC, 1)).build())
        b.addAction(Notification.Action.Builder(icon, if (Core.deaf) "เปิดหู" else "ปิดหู", servicePi(ACTION_EAR, 2)).build())
        b.addAction(Notification.Action.Builder(icon, "หยุด", servicePi(ACTION_STOP, 3)).build())
        return b.build()
    }
}
