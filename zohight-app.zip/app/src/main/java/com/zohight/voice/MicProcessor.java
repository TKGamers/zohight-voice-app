package com.zohight.voice;

/**
 * ปรับความดังไมค์: ปรับอัตโนมัติ (AGC) สำหรับคนเสียงเบา + ตัวคูณที่ผู้เล่นตั้งเอง + ลิมิตเตอร์กันแตก
 * เรียกใช้เฉพาะเฟรมที่กำลังพูด (เฟรมละ 320 ตัวอย่าง 16 kHz)
 */
public final class MicProcessor {
    private static final double TARGET = 0.10;   // ระดับเสียงพูดที่ต้องการ (RMS)
    private static final double MAX_AUTO = 12.0; // ขยายอัตโนมัติสูงสุด ~ +21 dB
    private static final double MIN_AUTO = 0.5;

    private double level = 0.0;
    private double agcGain = 1.0;
    private double prevTotal = 1.0;
    private double manual = 1.0;

    public void setManual(double g) {
        manual = Math.max(0.25, Math.min(4.0, g));
    }

    public double currentGain() {
        return prevTotal;
    }

    public void process(short[] x, int n, boolean agcOn) {
        double sq = 0;
        for (int i = 0; i < n; i++) {
            double f = x[i] / 32768.0;
            sq += f * f;
        }
        double rms = Math.sqrt(sq / Math.max(1, n));
        if (agcOn) {
            if (rms > 0.004) {
                level = level == 0.0 ? rms : 0.9 * level + 0.1 * rms;
                double desired = Math.max(MIN_AUTO, Math.min(MAX_AUTO, TARGET / level));
                if (desired < agcGain) agcGain += (desired - agcGain) * 0.3;   // ดังเกิน: ลดเร็ว
                else agcGain += (desired - agcGain) * 0.03;                      // เบา: ค่อยๆ เพิ่ม
            }
        } else {
            agcGain += (1.0 - agcGain) * 0.1;
        }
        double total = agcGain * manual;
        for (int i = 0; i < n; i++) {
            double g = prevTotal + (total - prevTotal) * (i + 1) / n;
            double y = x[i] / 32768.0 * g;
            double a = Math.abs(y);
            if (a > 0.8) {
                double s = y < 0 ? -1 : 1;
                y = s * (0.8 + 0.2 * Math.tanh((a - 0.8) / 0.2));
            }
            x[i] = (short) Math.round(y < 0 ? y * 32768 : y * 32767);
        }
        prevTotal = total;
    }
}
