package com.zohight.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * หัวใจของแอป: อัดเสียงจากไมค์ -> (ตัดเสียงรบกวน, ปรับความดัง) -> ส่งขึ้นเซิร์ฟเวอร์เสียง
 * รับเสียงคนอื่น -> ผสม (ดัง/เบาและซ้าย/ขวาตามที่เซิร์ฟเวอร์สั่ง) -> เล่นออกลำโพง
 * โปรโตคอลเดียวกับหน้าเว็บ: เสียง PCM 16-bit 16 kHz mono แพ็กเก็ตละ 20 ms (320 ตัวอย่าง)
 *
 * กันเสียงสะท้อน: ถ้าไม่ได้ใช้หูฟัง จะเข้าโหมด "โทรศัพท์" ของ Android (MODE_IN_COMMUNICATION + เปิดลำโพง
 * + เล่นเสียงแบบ VOICE_COMMUNICATION) เพื่อให้ตัวกันเสียงสะท้อนของเครื่องมีสัญญาณอ้างอิงเหมือนแอปโทรศัพท์ทั่วไป
 */
class VoiceClient(private val app: Context) {

    private class Voice {
        val q = java.util.ArrayDeque<ShortArray>()
        var primed = false
        var gain = 0f
        @Volatile var lastSeen = 0L
    }

    private val http = OkHttpClient.Builder().pingInterval(15, TimeUnit.SECONDS).build()
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var running = false
    @Volatile private var runGen = 0
    @Volatile private var audioGen = 0
    @Volatile private var wsGen = 0
    @Volatile private var ws: WebSocket? = null
    @Volatile private var wsReady = false
    @Volatile private var lastSetAt = 0L
    @Volatile private var hear: Map<Int, FloatArray> = emptyMap()
    @Volatile private var lastRecFrame = 0L
    @Volatile private var audioStarted = false
    @Volatile private var phoneMode = false   // โหมดโทรศัพท์ของ Android (เลือกเองเท่านั้น)
    @Volatile private var duckOn = false      // ลดไมค์ตอนมีคนอื่นพูดดัง (ใช้ลำโพง)
    private val sentCount = java.util.concurrent.atomic.AtomicInteger(0)
    private val recvCount = java.util.concurrent.atomic.AtomicInteger(0)
    private var audioFailCount = 0
    private var reconnectDelay = 2500L
    private var modeSet = false
    private var prevMode = AudioManager.MODE_NORMAL
    private val voices = ConcurrentHashMap<Int, Voice>()

    private companion object {
        const val RATE = 16000
        const val FRAME = 320
    }

    /* ---------------- เริ่ม / หยุด ---------------- */

    fun start() {
        if (running) return
        running = true
        runGen++
        reconnectDelay = 2500L
        audioFailCount = 0
        Core.running = true
        Core.conn = "connecting"
        Core.error = ""
        Core.notifyChange()
        connect()
        startAudio()
        main.removeCallbacks(supervisor)
        main.postDelayed(supervisor, 2000)
    }

    fun stop() {
        running = false
        runGen++
        audioGen++
        wsGen++
        wsReady = false
        audioStarted = false
        main.removeCallbacks(supervisor)
        try {
            ws?.close(1000, "bye")
        } catch (_: Exception) {
        }
        ws = null
        voices.clear()
        hear = emptyMap()
        resetRoute()
        Core.resetRuntime()
        Core.notifyChange()
    }

    private fun shutdown() {
        stop()
        Core.stopService?.invoke()
    }

    private fun fail(msg: String) {
        Core.error = msg
        main.post { shutdown() }
    }

    /** ตรวจทุก 2 วินาที: หูฟังเสียบ/ถอด -> สลับโหมดเสียง, ไมค์เงียบผิดปกติ -> เริ่มระบบเสียงใหม่ */
    private val supervisor = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                val want = wantPhoneMode()
                val stale = audioStarted && System.currentTimeMillis() - lastRecFrame > 5000
                if (want != phoneMode || stale) restartAudio()
                Core.diagSent = sentCount.getAndSet(0) / 2
                Core.diagRecv = recvCount.getAndSet(0) / 2
                Core.diagMode = if (phoneMode) "phone" else "media"
                Core.diagDuck = duckOn
                Core.notifyChange()
            } catch (_: Exception) {
            }
            main.postDelayed(this, 2000)
        }
    }

    private fun restartAudio() {
        audioGen++
        audioStarted = false
        val g = runGen
        main.postDelayed({ if (running && g == runGen) startAudio() }, 400)
    }

    private fun audioFail(msg: String) {
        audioFailCount++
        if (audioFailCount > 6) {
            fail(msg)
        } else {
            main.post { if (running) restartAudio() }
        }
    }

    /* ---------------- โหมดเสียง / การส่งออกเสียง ---------------- */

    /** โหมดโทรศัพท์ของ Android ใช้เฉพาะเมื่อผู้เล่นเลือก "โหมดโทรศัพท์" เองเท่านั้น (บางเครื่องทำให้เสียงเบาลง) */
    private fun wantPhoneMode(): Boolean = Core.echo == "on"

    private fun wantDuck(): Boolean {
        return when (Core.echo) {
            "on" -> true
            "off" -> false
            else -> !headsetPlugged()
        }
    }

    private fun headsetPlugged(): Boolean {
        return try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            var found = false
            for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                val t = d.type
                if (t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    t == AudioDeviceInfo.TYPE_USB_HEADSET
                ) {
                    found = true
                }
            }
            found
        } catch (e: Exception) {
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun applyRoute(speaker: Boolean) {
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (speaker) {
                if (!modeSet) {
                    prevMode = am.mode
                    modeSet = true
                }
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                try {
                    val maxV = am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL)
                    val curV = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
                    val wantV = (maxV * 0.8f).toInt()
                    if (curV < wantV) am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, wantV, 0)
                } catch (_: Exception) {
                }
                if (Build.VERSION.SDK_INT >= 31) {
                    for (d in am.availableCommunicationDevices) {
                        if (d.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) {
                            am.setCommunicationDevice(d)
                            break
                        }
                    }
                } else {
                    am.isSpeakerphoneOn = true
                }
            } else {
                resetRoute()
            }
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun resetRoute() {
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 31) {
                am.clearCommunicationDevice()
            } else {
                am.isSpeakerphoneOn = false
            }
            if (modeSet) {
                am.mode = prevMode
                modeSet = false
            }
        } catch (_: Exception) {
        }
    }

    private fun startAudio() {
        if (!running) return
        audioGen++
        val g = audioGen
        phoneMode = wantPhoneMode()
        applyRoute(phoneMode)
        audioStarted = true
        lastRecFrame = System.currentTimeMillis()
        val t1 = Thread {
            try {
                recLoop(g)
            } catch (t: Throwable) {
                audioFail("ไมค์ขัดข้อง: " + t.message)
            }
        }
        t1.name = "zv-rec"
        t1.start()
        val t2 = Thread {
            try {
                playLoop(g)
            } catch (t: Throwable) {
                audioFail("ลำโพงขัดข้อง: " + t.message)
            }
        }
        t2.name = "zv-play"
        t2.start()
    }

    /* ---------------- WebSocket ---------------- */

    private fun connect() {
        if (!running) return
        wsGen++
        val my = wsGen
        val base = Prefs.server(app).trimEnd('/')
        val url = base.replaceFirst("https://", "wss://").replaceFirst("http://", "ws://") + "/ws"
        val done = AtomicBoolean(false)
        val listener = object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (my != wsGen) return
                webSocket.send(JSONObject().put("t", "auth").put("token", Prefs.token(app)).toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (my != wsGen) return
                try {
                    handleText(webSocket, text)
                } catch (_: Exception) {
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (my != wsGen) return
                try {
                    handleVoice(bytes)
                } catch (_: Exception) {
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
                if (my == wsGen && done.compareAndSet(false, true)) lost(code)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (my == wsGen && done.compareAndSet(false, true)) lost(code)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (my == wsGen && done.compareAndSet(false, true)) lost(-1)
            }
        }
        ws = http.newWebSocket(Request.Builder().url(url).build(), listener)
    }

    private fun lost(code: Int) {
        wsReady = false
        hear = emptyMap()
        voices.clear()
        Core.online = false
        Core.hear = emptyList()
        Core.callWith = ""
        Core.callSt = ""
        if (code == 4002) {
            Prefs.clear(app)
            Core.error = "รหัสเชื่อมหมดอายุ กรุณาเชื่อมใหม่"
            shutdown()
            return
        }
        if (code == 4001) {
            Core.error = "มีอุปกรณ์อื่นเชื่อมแทนแล้ว"
            shutdown()
            return
        }
        Core.conn = "reconnecting"
        Core.notifyChange()
        val g = runGen
        val delay = reconnectDelay
        reconnectDelay = min(10000L, reconnectDelay + 1500L) // ถอยหลังทีละนิด ไม่ถล่มเซิร์ฟเวอร์
        main.postDelayed({ if (running && g == runGen) connect() }, delay)
    }

    private fun handleText(webSocket: WebSocket, text: String) {
        val m = JSONObject(text)
        val t = m.optString("t")
        if (t == "hello") {
            val mx = m.optInt("max", 0)
            if (mx > 0) Core.maxRange = mx
            webSocket.send("{\"t\":\"ready\"}")
            wsReady = true
            reconnectDelay = 2500L
            Core.conn = "connected"
            Core.error = ""
            Core.notifyChange()
        } else if (t == "mix") {
            val v = m.optJSONObject("v")
            val names = m.optJSONObject("names")
            val map = HashMap<Int, FloatArray>()
            val list = ArrayList<Triple<String, Float, Boolean>>()
            if (v != null) {
                val keys = v.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val a = v.getJSONArray(k)
                    val vol = a.getDouble(0).toFloat()
                    val pan = a.getDouble(1).toFloat()
                    val phone = a.length() > 2 && a.getInt(2) == 1
                    map[k.toInt()] = floatArrayOf(vol, pan)
                    val nm: String = names?.optString(k, "?") ?: "?"
                    list.add(Triple(nm, vol, phone))
                }
            }
            hear = map
            Core.hear = list
            val mx = m.optInt("max", 0)
            if (mx > 0) Core.maxRange = mx
            val me = m.optJSONObject("me")
            if (me != null) {
                Core.online = me.optBoolean("online", false)
                val call = me.optJSONObject("call")
                if (call != null) {
                    Core.callWith = call.optString("with", "")
                    Core.callSt = call.optString("st", "")
                } else {
                    Core.callWith = ""
                    Core.callSt = ""
                }
                if (Core.online && System.currentTimeMillis() - lastSetAt > 1500) {
                    Core.mic = me.optBoolean("mic", true)
                    Core.deaf = me.optBoolean("deaf", false)
                    Core.range = me.optInt("range", 15)
                    val g = me.optDouble("gain", Double.NaN)
                    if (!g.isNaN() && g > 0) Core.gain = g.toFloat()
                    if (me.has("agc")) Core.agc = me.optBoolean("agc", true)
                }
            }
            Core.notifyChange()
        }
    }

    private fun handleVoice(bytes: ByteString) {
        if (Core.deaf) return
        val b = bytes.toByteArray()
        if (b.size < 4) return
        val id = ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
        val n = (b.size - 2) / 2
        if (n != FRAME) return
        val s = ShortArray(n)
        ByteBuffer.wrap(b, 2, n * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(s)
        val v = voices.getOrPut(id) { Voice() }
        synchronized(v) {
            v.q.addLast(s)
            while (v.q.size > 12) v.q.removeFirst()
        }
        v.lastSeen = System.currentTimeMillis()
        recvCount.incrementAndGet()
    }

    /* ---------------- อัดเสียงจากไมค์ ---------------- */

    private fun recLoop(g: Int) {
        val minIn = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec: AudioRecord = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                max(minIn, FRAME * 2 * 8)
            )
        } catch (e: Exception) {
            audioFail("เปิดไมค์ไม่ได้: " + e.message)
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            audioFail("เปิดไมค์ไม่ได้ ตรวจสอบสิทธิ์ไมค์ของแอป")
            return
        }
        try {
            rec.startRecording()
        } catch (e: Exception) {
            rec.release()
            audioFail("เริ่มอัดเสียงไม่ได้: " + e.message)
            return
        }
        // ตัวช่วยของระบบ (ถ้าเครื่องมี): กันเสียงสะท้อน + ตัดเสียงรบกวน
        var aec: AcousticEchoCanceler? = null
        var pns: NoiseSuppressor? = null
        try {
            if (AcousticEchoCanceler.isAvailable()) {
                aec = AcousticEchoCanceler.create(rec.audioSessionId)
                aec?.setEnabled(true)
            }
            if (NoiseSuppressor.isAvailable()) {
                pns = NoiseSuppressor.create(rec.audioSessionId)
                pns?.setEnabled(Core.ns > 0)
            }
        } catch (_: Exception) {
        }
        val denoiser = Denoiser(Core.ns)
        val micProc = MicProcessor()
        val buf = ShortArray(FRAME)
        val bytes = ByteArray(FRAME * 2)
        var floor = 0.004f
        var hang = 0L
        var lastUi = 0L
        var lastGuardCheck = 0L
        while (running && g == audioGen) {
            var n = 0
            var bad = false
            while (n < FRAME && running && g == audioGen) {
                val r = rec.read(buf, n, FRAME - n)
                if (r < 0) {
                    bad = true
                    break
                }
                n += r
            }
            if (bad) {
                audioFail("อ่านเสียงจากไมค์ไม่ได้")
                break
            }
            if (n < FRAME) break
            lastRecFrame = System.currentTimeMillis()
            audioFailCount = 0

            if (Core.ns > 0) {
                denoiser.setLevel(Core.ns)
                denoiser.process(buf, FRAME)
            }
            var sum = 0.0
            for (i in 0 until FRAME) {
                val f = buf[i] / 32768.0
                sum += f * f
            }
            val rms = sqrt(sum / FRAME).toFloat()
            val now = System.currentTimeMillis()
            if (now - lastGuardCheck > 1500) {
                lastGuardCheck = now
                duckOn = wantDuck()
            }
            // ความไวของไมค์ปรับตามความดังที่ผู้เล่นตั้ง (คนเสียงเบาตั้งเพิ่มแล้วจะส่งเสียงได้ง่ายขึ้น)
            val rmsV = rms * Core.gain
            // ใช้ลำโพง: ถ้ามีคนอื่นกำลังพูดดัง ไมค์ต้องดังกว่านี้ถึงจะส่ง (ตัดเสียงสะท้อนที่เหลือ) จำกัดไว้ไม่ให้กดเสียงพูดจริงจนหาย
            val guardThr = if (duckOn) min(Core.far * 0.3f, 0.05f) else 0f
            val thr = max(max(0.004f, floor * 3f), guardThr)
            if (rmsV > thr) {
                hang = now + 350
            } else {
                floor = max(0.0015f, floor * 0.995f + rmsV * 0.005f)
            }
            val active = now < hang && Core.mic && !Core.deaf
            if (active && wsReady) {
                micProc.setManual(Core.gain.toDouble())
                micProc.process(buf, FRAME, Core.agc)
                ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(buf)
                ws?.send(bytes.toByteString(0, bytes.size))
                sentCount.incrementAndGet()
            }
            Core.diagMic = min(1f, rms * 8f)
            Core.speaking = active
            Core.level = if (Core.mic && !Core.deaf) min(1f, rms * 8f) else 0f
            if (now - lastUi > 100) {
                lastUi = now
                Core.notifyChange()
            }
        }
        try {
            aec?.release()
            pns?.release()
        } catch (_: Exception) {
        }
        try {
            rec.stop()
        } catch (_: Exception) {
        }
        rec.release()
    }

    /* ---------------- ผสมเสียงและเล่นออกลำโพง ---------------- */

    private fun playLoop(g: Int) {
        val minOut = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val usage = if (phoneMode) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA
        val track: AudioTrack = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(usage)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(max(minOut, FRAME * 4 * 6))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            audioFail("เปิดลำโพงไม่ได้: " + e.message)
            return
        }
        track.play()
        val acc = IntArray(FRAME * 2)
        val out = ShortArray(FRAME * 2)
        while (running && g == audioGen) {
            java.util.Arrays.fill(acc, 0)
            val now = System.currentTimeMillis()
            val deaf = Core.deaf
            val listen = Core.listen
            for ((id, v) in voices) {
                var frame: ShortArray? = null
                synchronized(v) {
                    if (!v.primed && v.q.size >= 3) v.primed = true
                    if (v.primed) {
                        frame = v.q.pollFirst()
                        if (frame == null) v.primed = false
                    }
                }
                val f = frame
                if (f == null) {
                    if (now - v.lastSeen > 5000) voices.remove(id)
                    continue
                }
                val tgt = hear[id]
                val tv = if (tgt != null) tgt[0] else 0f
                val pan = if (tgt != null) tgt[1] else 0f
                v.gain += (tv - v.gain) * 0.35f
                val gl = (if (pan > 0f) 1f - pan else 1f) * v.gain * listen
                val gr = (if (pan < 0f) 1f + pan else 1f) * v.gain * listen
                val len = min(f.size, FRAME)
                for (i in 0 until len) {
                    val s = f[i].toInt()
                    acc[2 * i] += (s * gl).toInt()
                    acc[2 * i + 1] += (s * gr).toInt()
                }
            }
            var sq = 0.0
            for (i in out.indices) {
                val x = if (deaf) 0 else acc[i]
                val c = if (x > 32767) 32767 else if (x < -32768) -32768 else x
                out[i] = c.toShort()
                val f = c / 32768.0
                sq += f * f
            }
            val lvl = sqrt(sq / out.size).toFloat()
            Core.far = max(lvl, Core.far * 0.97f)
            val w = track.write(out, 0, out.size)
            if (w < 0) {
                audioFail("เขียนเสียงออกลำโพงไม่ได้")
                break
            }
        }
        try {
            track.stop()
        } catch (_: Exception) {
        }
        track.release()
    }

    /* ---------------- ตั้งค่าจากหน้าจอ / ปุ่มในแจ้งเตือน ---------------- */

    private fun sendSet(o: JSONObject) {
        o.put("t", "set")
        if (wsReady) ws?.send(o.toString())
    }

    fun setMic(on: Boolean) {
        lastSetAt = System.currentTimeMillis()
        Core.mic = on
        sendSet(JSONObject().put("mic", on))
        Core.onSettings?.invoke()
        Core.notifyChange()
    }

    fun setDeaf(on: Boolean) {
        lastSetAt = System.currentTimeMillis()
        Core.deaf = on
        sendSet(JSONObject().put("deaf", on))
        Core.onSettings?.invoke()
        Core.notifyChange()
    }

    fun setRange(n: Int) {
        lastSetAt = System.currentTimeMillis()
        val r = max(1, min(Core.maxRange, n))
        Core.range = r
        sendSet(JSONObject().put("range", r))
        Core.notifyChange()
    }

    fun setGain(g: Float) {
        lastSetAt = System.currentTimeMillis()
        val v = max(0.25f, min(4f, g))
        Core.gain = v
        sendSet(JSONObject().put("gain", v.toDouble()))
        Core.notifyChange()
    }

    fun setAgc(on: Boolean) {
        lastSetAt = System.currentTimeMillis()
        Core.agc = on
        sendSet(JSONObject().put("agc", on))
        Core.notifyChange()
    }

    fun hangup() {
        if (wsReady) ws?.send("{\"t\":\"callact\",\"act\":\"hangup\"}")
    }

    fun toggleMic() {
        if (Core.deaf) {
            setDeaf(false)
            setMic(true)
        } else {
            setMic(!Core.mic)
        }
    }

    fun toggleDeaf() {
        setDeaf(!Core.deaf)
    }
}
