package com.zohight.voice;

/**
 * ตัดเสียงรบกวนแบบสเปกตรัม (Wiener + minimum statistics) สำหรับเสียง 16 kHz mono
 * ป้อนทีละ 320 ตัวอย่างได้ (ความยาวเท่าไรก็ได้) หน่วงประมาณ 32 ms
 * level: 0 = ปิด, 1 = กลาง, 2 = แรง
 */
public final class Denoiser {
    private static final int N = 512;
    private static final int H = 256;
    private static final int K = 257;
    private static final int U = 8;
    private static final int V = 12;

    private final double[] win = new double[N];
    private final double[] cosT = new double[N / 2];
    private final double[] sinT = new double[N / 2];
    private final int[] rev = new int[N];
    private final double[] re = new double[N];
    private final double[] im = new double[N];
    private final double[] smooth = new double[K];
    private final double[] minCur = new double[K];
    private final double[][] hist = new double[U][K];
    private final double[] prevClean = new double[K];
    private final double[] gPrev = new double[K];
    private final double[] gain = new double[K];
    private final double[] p = new double[K];
    private double[] inQ = new double[N + 1024];
    private int inLen = 0;
    private final double[] outAcc = new double[N];
    private final double[] outQ = new double[4096];
    private int outLen = N;
    private int frames = 0;
    private int u = 0;
    private double noiseScale = 1.0;
    private double gMin = 0.11;

    public Denoiser(int level) {
        for (int n = 0; n < N; n++) win[n] = Math.sin(Math.PI * (n + 0.5) / N);
        for (int i = 0; i < N / 2; i++) {
            cosT[i] = Math.cos(2 * Math.PI * i / N);
            sinT[i] = -Math.sin(2 * Math.PI * i / N);
        }
        int bits = 9;
        for (int i = 0; i < N; i++) {
            int r = 0;
            for (int b = 0; b < bits; b++) if ((i & (1 << b)) != 0) r |= 1 << (bits - 1 - b);
            rev[i] = r;
        }
        java.util.Arrays.fill(minCur, 1e18);
        for (int i = 0; i < U; i++) java.util.Arrays.fill(hist[i], 1e18);
        java.util.Arrays.fill(gPrev, 1.0);
        setLevel(level);
    }

    public void setLevel(int level) {
        if (level >= 2) {
            noiseScale = 1.5;
            gMin = 0.035;
        } else {
            noiseScale = 1.0;
            gMin = 0.11;
        }
    }

    private void fft(boolean inverse) {
        for (int i = 0; i < N; i++) {
            int j = rev[i];
            if (j > i) {
                double t = re[i]; re[i] = re[j]; re[j] = t;
                t = im[i]; im[i] = im[j]; im[j] = t;
            }
        }
        for (int size = 2; size <= N; size <<= 1) {
            int half = size >> 1;
            int step = N / size;
            for (int i = 0; i < N; i += size) {
                for (int j = 0, k = 0; j < half; j++, k += step) {
                    double wr = cosT[k];
                    double wi = inverse ? -sinT[k] : sinT[k];
                    int a = i + j;
                    int b = a + half;
                    double tr = re[b] * wr - im[b] * wi;
                    double ti = re[b] * wi + im[b] * wr;
                    re[b] = re[a] - tr;
                    im[b] = im[a] - ti;
                    re[a] += tr;
                    im[a] += ti;
                }
            }
        }
        if (inverse) {
            for (int i = 0; i < N; i++) {
                re[i] /= N;
                im[i] /= N;
            }
        }
    }

    private void frame() {
        for (int n = 0; n < N; n++) {
            re[n] = inQ[n] * win[n];
            im[n] = 0;
        }
        fft(false);
        for (int k = 0; k < K; k++) p[k] = re[k] * re[k] + im[k] * im[k];
        boolean first = frames == 0;
        for (int k = 0; k < K; k++) {
            smooth[k] = first ? p[k] : 0.85 * smooth[k] + 0.15 * p[k];
            if (smooth[k] < minCur[k]) minCur[k] = smooth[k];
        }
        frames++;
        if (frames % V == 0) {
            System.arraycopy(minCur, 0, hist[u], 0, K);
            u = (u + 1) % U;
            System.arraycopy(smooth, 0, minCur, 0, K);
        }
        for (int k = 0; k < K; k++) {
            double nmin = minCur[k];
            for (int q = 0; q < U; q++) if (hist[q][k] < nmin) nmin = hist[q][k];
            double noise = Math.max(nmin * 1.7 * noiseScale, 1e-3);
            double gamma = p[k] / noise;
            double xi = 0.98 * prevClean[k] / noise + 0.02 * Math.max(gamma - 1, 0);
            if (xi < 0.003) xi = 0.003;
            double g = xi / (1 + xi);
            gain[k] = g < gMin ? gMin : g;
        }
        for (int k = 0; k < K; k++) {
            double a = gain[k > 0 ? k - 1 : k];
            double b = gain[k];
            double c = gain[k < K - 1 ? k + 1 : k];
            double g = 0.25 * a + 0.5 * b + 0.25 * c;
            if (g < gPrev[k]) g = 0.5 * g + 0.5 * gPrev[k];
            gPrev[k] = g;
            prevClean[k] = g * g * p[k];
            re[k] *= g;
            im[k] *= g;
        }
        for (int k = K; k < N; k++) {
            re[k] = re[N - k];
            im[k] = -im[N - k];
        }
        fft(true);
        for (int n = 0; n < N; n++) outAcc[n] += re[n] * win[n];
        for (int n = 0; n < H; n++) outQ[outLen++] = outAcc[n];
        System.arraycopy(outAcc, H, outAcc, 0, N - H);
        java.util.Arrays.fill(outAcc, N - H, N, 0.0);
    }

    /** ประมวลผลในที่เดิม (x[0..n) ถูกแทนด้วยเสียงที่ตัดรบกวนแล้ว) */
    public void process(short[] x, int n) {
        if (inLen + n > inQ.length) {
            double[] t = new double[inLen + n + 1024];
            System.arraycopy(inQ, 0, t, 0, inLen);
            inQ = t;
        }
        for (int i = 0; i < n; i++) inQ[inLen++] = x[i] / 32768.0;
        while (inLen >= N) {
            frame();
            System.arraycopy(inQ, H, inQ, 0, inLen - H);
            inLen -= H;
        }
        for (int i = 0; i < n; i++) {
            double v = i < outLen ? outQ[i] : 0.0;
            if (v > 1) v = 1;
            if (v < -1) v = -1;
            x[i] = (short) (v < 0 ? v * 32768 : v * 32767);
        }
        int rest = Math.max(0, outLen - n);
        System.arraycopy(outQ, Math.min(n, outLen), outQ, 0, rest);
        outLen = rest;
    }
}
