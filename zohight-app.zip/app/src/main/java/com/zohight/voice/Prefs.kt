package com.zohight.voice

import android.content.Context

/** เก็บโทเคนที่เชื่อมไว้ในเครื่อง เพื่อไม่ต้องใส่รหัสซ้ำ */
object Prefs {
    // ที่อยู่เซิร์ฟเวอร์เสียงของคุณ (ถ้าย้ายเซิร์ฟเวอร์ ให้แก้บรรทัดนี้แล้วสร้างแอปใหม่)
    const val DEFAULT_SERVER = "https://highz-voice.onrender.com"

    private fun sp(c: Context) = c.getSharedPreferences("zv", Context.MODE_PRIVATE)

    fun token(c: Context): String = sp(c).getString("token", "") ?: ""
    fun name(c: Context): String = sp(c).getString("name", "") ?: ""
    fun server(c: Context): String = sp(c).getString("server", DEFAULT_SERVER) ?: DEFAULT_SERVER

    fun ns(c: Context): Int = sp(c).getInt("ns", 1)
    fun echo(c: Context): String = sp(c).getString("echo", "auto") ?: "auto"
    fun saveNs(c: Context, v: Int) { sp(c).edit().putInt("ns", v).apply() }
    fun saveEcho(c: Context, v: String) { sp(c).edit().putString("echo", v).apply() }

    fun save(c: Context, token: String, name: String) {
        sp(c).edit().putString("token", token).putString("name", name).apply()
    }

    fun clear(c: Context) {
        sp(c).edit().remove("token").remove("name").apply()
    }
}
