package com.zohight.voice;

/**
 * เสียง 3 มิติแบบง่าย (เหมาะกับหูฟัง) ต่อ 1 ผู้พูด: หน่วงเวลาระหว่างหู (ITD) + ต่างระดับเสียงระหว่างหู (ILD)
 * + เสียงจากด้านหลังอู้กว่าด้านหน้า + เสียงลอดผ่านกำแพงอู้ลง (occlusion)
 * az: มุมจากด้านหน้าผู้ฟัง (เรเดียน, 0 = ตรงหน้า, บวก = ขวา, ±π = ด้านหลัง) / occ: 0..1
 */
public final class Spatializer {
    private static final int RATE = 16000;
    private static final double MAX_ITD = 10.5; // ตัวอย่าง (~0.66 ms)
    private final float[] buf = new float[128];
    private int wp = 0;
    private double lp1 = 0, lp2 = 0, lp3 = 0, lp4 = 0;
    private double gl = 1, gr = 1, itd = 0;
    private boolean init = false;

    private static double coef(double fc) {
        return 1.0 - Math.exp(-2.0 * Math.PI * fc / RATE);
    }

    /** x: เสียงเดี่ยว n ตัวอย่าง -> เขียนเข้า outL/outR (เกนรวมให้ผู้เรียกคูณเอง) */
    public void process(short[] x, int n, double az, double occ, float[] outL, float[] outR) {
        double lat = Math.sin(az);                     // -1 ซ้าย .. +1 ขวา
        double rear = Math.max(0.0, -Math.cos(az));    // 0 หน้า .. 1 หลัง
        double tgl = (1.0 - Math.max(0.0, lat) * 0.7) * (1.0 - 0.2 * rear);
        double tgr = (1.0 + Math.min(0.0, lat) * 0.7) * (1.0 - 0.2 * rear);
        double titd = MAX_ITD * lat;                   // บวก = หูซ้ายได้ยินช้ากว่า
        if (!init) { gl = tgl; gr = tgr; itd = titd; init = true; }
        double fc = Math.min(7500.0 - 4800.0 * rear, 7500.0 - 6700.0 * occ);
        double a = coef(Math.max(500.0, fc));
        for (int i = 0; i < n; i++) {
            double t = (i + 1.0) / n;
            double g1 = gl + (tgl - gl) * t, g2 = gr + (tgr - gr) * t, d = itd + (titd - itd) * t;
            double s = x[i] / 32768.0;
            lp1 += a * (s - lp1);
            lp2 += a * (lp1 - lp2);
            double y = lp2;
            if (occ > 0.02) { lp3 += a * (y - lp3); lp4 += a * (lp3 - lp4); y = lp4; }   // ผ่านกำแพง: กรองหนักขึ้นอีกชั้น
            buf[wp] = (float) y;
            double dl = d > 0 ? d : 0.0, dr = d < 0 ? -d : 0.0;
            outL[i] = (float) (read(dl) * g1);
            outR[i] = (float) (read(dr) * g2);
            wp = (wp + 1) & 127;
        }
        gl = tgl; gr = tgr; itd = titd;
    }

    private float read(double delay) {
        double pos = wp - delay;
        int i0 = (int) Math.floor(pos);
        double fr = pos - i0;
        float a = buf[i0 & 127], b = buf[(i0 + 1) & 127];
        return (float) (a + (b - a) * fr);
    }
}
